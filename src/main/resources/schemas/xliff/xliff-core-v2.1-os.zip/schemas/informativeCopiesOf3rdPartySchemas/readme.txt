IMPORTANT WARNING
Schema copies in this sub-folder are provided solely for implementers convenience and are NOT a part of the OASIS multipart product.
These schemas belong to their respective owners and their use is governed by their owners' respective IPR policies.
The support schemas are organized in folders per owner/maintainer.
It is the implemnter's sole responsibility to ensure that their local copies of all schemas are the appropriate up to date versions.

Included 3rd Party Support Schemas:
-----------------------------------
http://www.w3.org/2001/xml.xsd [http://www.w3.org/2009/01/xml.xsd] here under /w3c/xml.xsd
change_tracking.xsd here under /extensions/change_tracking.xsd